# Vasista Reddy Portfolio

A Wix-free portfolio recreated as a static HTML/CSS website.

## Files
- `index.html` — website
- `style.css` — styling
- `resume.pdf` — add your resume PDF here before publishing

## Free hosting
GitHub Pages can host this static site for free from a public repository.

1. Create a GitHub account if you don't have one.
2. Create a repository named `YOURUSERNAME.github.io`.
3. Upload `index.html` and `style.css`.
4. Upload your resume as `resume.pdf`.
5. Go to Settings → Pages and enable GitHub Pages.
6. Your site will be available at `https://YOURUSERNAME.github.io/`.
